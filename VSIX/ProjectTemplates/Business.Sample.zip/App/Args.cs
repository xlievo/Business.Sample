﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Core.Annotations;
using Common;

/// <summary>
/// MyLogicArg!
/// </summary>
public struct MyLogicArg
{
    /// <summary>
    /// AAA
    /// </summary>
    [Common.CheckNull]
    public string A { get; set; }

    /// <summary>
    /// BBB
    /// </summary>
    public string B { get; set; }
}

public struct WebSocketPushLogicResult
{
    /// <summary>
    /// CCC
    /// </summary>
    public string C { get; set; }

    /// <summary>
    /// DDD
    /// </summary>
    public string D { get; set; }
}
