﻿using Business.Core;
using Business.Core.Annotations;
using Business.Core.Auth;
using Business.Core.Result;
using Business.AspNet;
using LinqToDB;
using DataModel;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//Maybe you need a custom base class? To unify the processing of logs and token
public class MyBusiness : BusinessBase
{
    //My first business logic
    //Logical method must be public virtual!
    //If inherited Business.AspNet.BusinessBase Base class, you just need to concentrate on writing logical methods!
    public virtual async ValueTask<IResult<MyLogicArg>> MyLogic(Token token, Context context, HttpFile files, MyLogicArg arg)
    {
        return this.ResultCreate(arg);
    }

    #region webSocket push case

    [Push]
    public virtual async ValueTask<IResult<WebSocketPushLogicResult>> WebSocketPushLogic(Token token, MyLogicArg arg, [Ignore(IgnoreMode.Arg)] params string[] id)
    {
        var pushResult = new WebSocketPushLogicResult { C = arg.A, D = arg.B };

        this.SendAsync(pushResult, id);// The push data must be consistent with the return object

        return this.ResultCreate(pushResult);// Used as a return standard convention
    }

    #endregion
}